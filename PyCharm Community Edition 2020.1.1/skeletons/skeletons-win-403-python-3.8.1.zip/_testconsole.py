# encoding: utf-8
# module _testconsole
# from (pre-generated)
# by generator 1.147
""" Test module for the Windows console """
# no imports

# functions

def read_output(*args, **kwargs): # real signature unknown
    """ Reads a str from the console as written to stdout. """
    pass

def write_input(*args, **kwargs): # real signature unknown
    """ Writes UTF-16-LE encoded bytes to the console as if typed by a user. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x000001E37F9829A0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_testconsole', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x000001E37F9829A0>, origin='C:\\\\BuildAgent\\\\system\\\\.persistent_cache\\\\pythons\\\\python38\\\\DLLs\\\\_testconsole.pyd')"

