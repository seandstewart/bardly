# encoding: utf-8
# module _sha256
# from (built-in)
# by generator 1.147
# no doc
# no imports

# functions

def sha224(*args, **kwargs): # real signature unknown
    """ Return a new SHA-224 hash object; optionally initialized with a string. """
    pass

def sha256(*args, **kwargs): # real signature unknown
    """ Return a new SHA-256 hash object; optionally initialized with a string. """
    pass

# no classes
